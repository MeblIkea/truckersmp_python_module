from setuptools import setup

setup(name='truckersmp_api',
      version='0.1',
      description='This plugin is just truckersmp api, but Python friendly',
      url='http://localhost/',
      author='MeblIkea',
      author_email='MeblIkea@6651.discord',
      license='MIT',
      requires=['requests'],
      zip_safe=False)
